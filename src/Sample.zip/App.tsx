import React from 'react';
import './App.css';
import { GanttComponent, TaskFieldsModel, ColumnsDirective, ColumnDirective, Edit, Inject, Selection } from '@syncfusion/ej2-react-gantt';
import { TreeViewComponent } from '@syncfusion/ej2-react-navigations';
import { closest } from '@syncfusion/ej2-base';
import { resourceData, resourceDetails } from './data';
function App() {
  let ganttInst: GanttComponent | null;
  const taskValues: TaskFieldsModel = {
    id: "TaskID",
    name: "TaskName",
    startDate: "StartDate",
    endDate: "EndDate",
    duration: "Duration",
    progress: "Progress",
    dependency: "Predecessor",
    child: "subtasks",
    resourceInfo: "resources"
  }
  const onDragStop =(args: any) =>{
    let chartEle: any = closest(args.target, '.e-chart-row');
    let gridEle: any = closest(args.target, '.e-row');
    let gantObj = (ganttInst as GanttComponent);
    if (gridEle) {
      // To find the row where the resource is drroped
      var index = gantObj.treeGrid.getRows().indexOf(gridEle);
      // To select the row in Gantt Chart to drop the resource
      gantObj.selectRow(index);
  }
  let record: any = args.draggedNodeData; // constains the details of item which is draaged
  let selectedData: any = gantObj.flatData[gantObj.selectedRowIndex]; // get the selected record details in Gantt
  let selectedDataResource: any = selectedData.taskData.resources;
  let resources = [];
  if (selectedDataResource) {
      for (var i = 0; i < selectedDataResource.length; i++) {
          resources.push(selectedDataResource[i].resourceId);
      }
  }
  resources.push(parseInt(record.id));
  if (chartEle || gridEle) {
      var data = {
          TaskID: selectedData.taskData.TaskID,
          resources: resources
      };
      gantObj.updateRecordByID(data);
      var elements = document.querySelectorAll('.e-drag-item');
      while (elements.length > 0 && elements[0].parentNode) {
          elements[0].parentNode.removeChild(elements[0]);
      }
  }
  }
  return (
    <div>
      <GanttComponent ref={gantt => ganttInst = gantt} dataSource={resourceData}
      editSettings={{allowEditing: true}}
      taskFields={taskValues} resources={resourceDetails}
      resourceFields={{id: "resourceId", name: "resourceName"}}>
        <Inject services={[Edit, Selection]}></Inject>
        <ColumnsDirective>
          <ColumnDirective field="TaskName" headerText="Name"></ColumnDirective>
          <ColumnDirective field="Duration" textAlign="Right" width="100"></ColumnDirective>
          <ColumnDirective field="resources" headerText="Resources" width="250"></ColumnDirective>
        </ColumnsDirective>
      </GanttComponent>

      <TreeViewComponent fields={{ dataSource: resourceDetails, id: "resourceId", text: "resourceName"}}
      allowDragAndDrop={true} nodeDragStop={onDragStop}></TreeViewComponent>
    </div>
  );
}

export default App;
